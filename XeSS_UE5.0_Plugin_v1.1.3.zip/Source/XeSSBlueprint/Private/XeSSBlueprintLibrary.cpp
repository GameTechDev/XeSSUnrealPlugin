/*******************************************************************************
 * Copyright 2021 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files(the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions :
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ******************************************************************************/

#include "XeSSBlueprintLibrary.h"

#if USE_XESS
#include "XeSSModule.h"
#include "XeSSUpscaler.h"

THIRD_PARTY_INCLUDES_START
#include "xess.h"
#include "xess_d3d12.h"
#include "xess_d3d12_debug.h"
#include "xess_debug.h"
THIRD_PARTY_INCLUDES_START
#endif

#define LOCTEXT_NAMESPACE "UXeSSBlueprintLibrary"
#define XESS_QUALITY_SETTING_BASE_VALUE (XESS_QUALITY_SETTING_PERFORMANCE-1)

bool UXeSSBlueprintLibrary::bXeSSSupported = false;
#if USE_XESS
FXeSSUpscaler* UXeSSBlueprintLibrary::XeSSUpscaler = nullptr;

int XeSSSettingToCVar(xess_quality_settings_t Option)
{
	const int CVarQualityValue = Option - XESS_QUALITY_SETTING_BASE_VALUE;
	return CVarQualityValue;
}
#endif

bool UXeSSBlueprintLibrary::IsXeSSSupported()
{
	return UXeSSBlueprintLibrary::bXeSSSupported;
}

TArray<EXeSSQualityMode> UXeSSBlueprintLibrary::GetSupportedXeSSQualityModes()
{
	TArray<EXeSSQualityMode> SupportedXeSSQualityModes;
	const UEnum* QualityOptionEnum = StaticEnum<EXeSSQualityMode>();

	if (ensure(QualityOptionEnum))
	{
		for (int32 EnumIndex = 0; EnumIndex < QualityOptionEnum->NumEnums(); ++EnumIndex)
		{
			const int32 EnumValue = (int32)QualityOptionEnum->GetValueByIndex(EnumIndex);
			if (EnumValue != QualityOptionEnum->GetMaxEnumValue())
			{
				SupportedXeSSQualityModes.Add(EXeSSQualityMode(EnumValue));
			}
		}
	}

	return SupportedXeSSQualityModes;
}

EXeSSQualityMode UXeSSBlueprintLibrary::GetXeSSQualityMode()
{
#if USE_XESS
	static const auto CVarXeSSQuality = IConsoleManager::Get().FindConsoleVariable(TEXT("r.XeSS.Quality"));
	int XeSSQuality = CVarXeSSQuality->GetInt();

	// if XeSS Upscaler did not initialize correctly
	if (!UXeSSBlueprintLibrary::XeSSUpscaler)
	{
		return EXeSSQualityMode::Off;
	}

	bool bXeSSEnabled = UXeSSBlueprintLibrary::XeSSUpscaler->IsXeSSEnabled();	
	if (!bXeSSEnabled)
	{
		return EXeSSQualityMode::Off;
	}

	uint32_t QualityIndex = static_cast<uint32_t>(XESS_QUALITY_SETTING_BASE_VALUE) + XeSSQuality;
	xess_quality_settings_t QualityMode = static_cast<xess_quality_settings_t>(QualityIndex);

	switch (QualityMode)
	{
	case XESS_QUALITY_SETTING_PERFORMANCE:
		return EXeSSQualityMode::Performance;
	case XESS_QUALITY_SETTING_BALANCED:
		return EXeSSQualityMode::Balanced;
	case XESS_QUALITY_SETTING_QUALITY:
		return EXeSSQualityMode::Quality;
	case XESS_QUALITY_SETTING_ULTRA_QUALITY:
		return EXeSSQualityMode::UltraQuality;
	default:
#if !UE_BUILD_SHIPPING
		const UEnum* Enum = StaticEnum<EXeSSQualityMode>();
		FFrame::KismetExecutionMessage(*FString::Printf(TEXT("SetXeSSQualityMode called with invalid enum value (%d) %s"),
			int32(QualityMode), *Enum->GetDisplayNameTextByValue(int32(QualityMode)).ToString()), ELogVerbosity::Error);
#endif 
		return EXeSSQualityMode::Off;
	}
#else 
	return EXeSSQualityMode::Off;
#endif
}

EXeSSQualityMode UXeSSBlueprintLibrary::GetDefaultXeSSQualityMode(FIntPoint ScreenResolution)
{
	// For resolutions equal to and lower than 2560x1440 the default quality mode should be set to Balanced
	// Otherwise Performance should be used
	int PixelCount = ScreenResolution.X * ScreenResolution.Y;
	if (PixelCount <= 2560 * 1440)
	{
		return EXeSSQualityMode::Balanced;
	}
	
	return EXeSSQualityMode::Performance;
}

void UXeSSBlueprintLibrary::SetXeSSQualityMode(EXeSSQualityMode QualityMode)
{
#if USE_XESS
	const UEnum* Enum = StaticEnum<EXeSSQualityMode>();

	// Sanity check
	if (!Enum->IsValidEnumValue(int32(QualityMode)))
	{
#if !UE_BUILD_SHIPPING
		FFrame::KismetExecutionMessage(*FString::Printf(TEXT("SetXeSSQualityMode called with invalid enum value (%d) %s"),
			int32(QualityMode), *Enum->GetDisplayNameTextByValue(int32(QualityMode)).ToString()), ELogVerbosity::Error);
#endif 
			return;
	}

	static const auto CVarXeSSEnabled = IConsoleManager::Get().FindConsoleVariable(TEXT("r.XeSS.Enabled"));
	static const auto CVarXeSSQuality = IConsoleManager::Get().FindConsoleVariable(TEXT("r.XeSS.Quality"));

	if (QualityMode == EXeSSQualityMode::Off)
	{
		CVarXeSSEnabled->Set(0, ECVF_SetByConsole);
		return;
	}

	xess_quality_settings_t XeSSQuality = XESS_QUALITY_SETTING_BALANCED;
	switch (QualityMode)
	{
	case EXeSSQualityMode::Performance:
		XeSSQuality = XESS_QUALITY_SETTING_PERFORMANCE;
		break;
	case EXeSSQualityMode::Balanced:
		XeSSQuality = XESS_QUALITY_SETTING_BALANCED;
		break;
	case EXeSSQualityMode::Quality:
		XeSSQuality = XESS_QUALITY_SETTING_QUALITY;
		break;
	case EXeSSQualityMode::UltraQuality:
		XeSSQuality = XESS_QUALITY_SETTING_ULTRA_QUALITY;
		break;
	}

	CVarXeSSQuality->Set(XeSSSettingToCVar(XeSSQuality), ECVF_SetByConsole);
	CVarXeSSEnabled->Set(1, ECVF_SetByConsole);
#endif
}

void FXeSSBlueprint::StartupModule()
{
#if USE_XESS
	FXeSSPlugin* XeSSPlugin = &FModuleManager::LoadModuleChecked<FXeSSPlugin>(TEXT("XeSSPlugin"));
	check(XeSSPlugin);
	UXeSSBlueprintLibrary::XeSSUpscaler = XeSSPlugin->GetXeSSUpscaler();

	// if the platform doesn't support XeSS the Upscaler won't be created
	if (UXeSSBlueprintLibrary::XeSSUpscaler)
	{
		UXeSSBlueprintLibrary::bXeSSSupported = true;
	}
#endif
}

void FXeSSBlueprint::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FXeSSBlueprint, XeSSBlueprint)