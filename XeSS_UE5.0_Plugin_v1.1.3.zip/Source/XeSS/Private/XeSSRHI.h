/*******************************************************************************
 * Copyright 2021 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files(the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions :
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ******************************************************************************/

#pragma once

#include "Modules/ModuleManager.h"

#include "CoreMinimal.h"
#include "RendererInterface.h"

#include "Windows/AllowWindowsPlatformTypes.h"
THIRD_PARTY_INCLUDES_START
#include "xess.h"
#include "xess_d3d12.h"
#include "xess_d3d12_debug.h"
#include "xess_debug.h"
THIRD_PARTY_INCLUDES_START

DECLARE_LOG_CATEGORY_EXTERN(LogXeSS, Verbose, All);

class FD3D12DynamicRHI;
struct ID3D12Device;

struct XESSPLUGIN_API FXeSSInitArguments
{
	uint32_t OutputWidth = 0;
	uint32_t OutputHeight = 0;
	uint32_t QualitySetting = 0;
};

struct XESSPLUGIN_API FXeSSExecuteArguments
{
	FRHITexture* ColorTexture = nullptr;
	FRHITexture* VelocityTexture = nullptr;
	FRHITexture* OutputTexture = nullptr;

	float JitterOffsetX = 0.0f;
	float JitterOffsetY = 0.0f;

	FIntRect SrcViewRect = FIntRect(FIntPoint::ZeroValue, FIntPoint::ZeroValue);
	FIntRect DstViewRect = FIntRect(FIntPoint::ZeroValue, FIntPoint::ZeroValue);

	int bCameraCut = 0;

};

class XESSPLUGIN_API FXeSSRHI
{
	
public:
	FXeSSRHI(FDynamicRHI* DynamicRHI);
	virtual ~FXeSSRHI();

	void RHIInitializeXeSS(FRHICommandList& CmdList, const FXeSSInitArguments& InArguments);
	bool EffectRecreationIsRequired(const FXeSSInitArguments& NewArgs) const;
	void RHIExecuteXeSS(FRHICommandList& CmdList, const FXeSSExecuteArguments& InArguments);
	float GetCurrentResolutionFraction() { return CurrentResolutionFraction; }
	float GetMinSupportedResolutionFraction() const { return MinResolutionFraction; }
	float GetMaxSupportedResolutionFraction() const { return MaxResolutionFraction; }
	void TriggerFrameCapture(int FrameCount) const;
	void TriggerResourceTransitions(FRHICommandListImmediate& RHICmdList, FRHIStructuredBuffer* DummyBuffer) const;

	static bool IsXeSSInitialized() { return bXeSSInitialized; }
	void UpdateInitArguments(const FXeSSInitArguments& NewArgs) { InitArgs = NewArgs; }

private:
	FD3D12DynamicRHI* D3D12RHI = nullptr;
	ID3D12Device* Direct3DDevice = nullptr;
	FXeSSInitArguments InitArgs;

	xess_context_handle_t XeSSContext = nullptr;

	static bool bXeSSInitialized;
	static float MinResolutionFraction;
	static float MaxResolutionFraction;
	static float CurrentResolutionFraction;

	float SetResolutionFraction(const xess_2d_t& OutputResolution, const xess_quality_settings_t QualitySettings);
};

#include "Windows/HideWindowsPlatformTypes.h"