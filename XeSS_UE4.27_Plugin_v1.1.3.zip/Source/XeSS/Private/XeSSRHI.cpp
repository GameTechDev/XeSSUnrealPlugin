/*******************************************************************************
 * Copyright 2021 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files(the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions :
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ******************************************************************************/

#include "XeSSRHI.h"

#include "D3D12RHIPrivate.h"
#include "D3D12Util.h"
#include "D3D12State.h"
#include "D3D12Resources.h"
#include "D3D12Viewport.h"
#include "D3D12ConstantBuffer.h"

#include "HAL/FileManager.h"
#include "Interfaces/IPluginManager.h"
#include "Windows/AllowWindowsPlatformTypes.h"
#include "Windows/HideWindowsPlatformTypes.h"

#include "GeneralProjectSettings.h"

#include "SceneViewExtension.h"
#include "SceneView.h"

// The UE module
DEFINE_LOG_CATEGORY_STATIC(LogXeSSRHI, Log, All);

#define LOCTEXT_NAMESPACE "FXeSSPlugin"
#define XESS_QUALITY_SETTING_BASE_VALUE (XESS_QUALITY_SETTING_PERFORMANCE-1)

static TAutoConsoleVariable<FString> CVarXeSSFrameDumpPath(
	TEXT("r.XeSS.FrameDumpPath"),
	TEXT("."),
	TEXT("Select path for frame capture dumps, if not specified the game's binary directory will be used."),
	ECVF_Default);

static uint32_t XeSSInitFlags = XESS_INIT_FLAG_HIGH_RES_MV;
bool FXeSSRHI::bXeSSInitialized = false;
float FXeSSRHI::MinResolutionFraction;
float FXeSSRHI::MaxResolutionFraction;
float FXeSSRHI::CurrentResolutionFraction;

// temporary workaround for missing resource barrier flush in UE5
inline void ForceBeforeResourceTransition(ID3D12GraphicsCommandList& D3D12CmdList, const xess_d3d12_execute_params_t& ExecuteParams)
{
#if ENGINE_MAJOR_VERSION >= 5
	TArray<CD3DX12_RESOURCE_BARRIER> OutTransitions;
	OutTransitions.Add(CD3DX12_RESOURCE_BARRIER::Transition(ExecuteParams.pColorTexture,
		D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE));
	OutTransitions.Add(CD3DX12_RESOURCE_BARRIER::Transition(ExecuteParams.pVelocityTexture,
		D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE));

	D3D12CmdList.ResourceBarrier(OutTransitions.Num(), OutTransitions.GetData());
#endif
};

inline void ForceAfterResourceTransition(ID3D12GraphicsCommandList& D3D12CmdList, const xess_d3d12_execute_params_t& ExecuteParams)
{
#if ENGINE_MAJOR_VERSION >= 5
	TArray<CD3DX12_RESOURCE_BARRIER> OutTransitions;
	OutTransitions.Add(CD3DX12_RESOURCE_BARRIER::Transition(ExecuteParams.pColorTexture,
		D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET));
	OutTransitions.Add(CD3DX12_RESOURCE_BARRIER::Transition(ExecuteParams.pVelocityTexture,
		D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS));

	D3D12CmdList.ResourceBarrier(OutTransitions.Num(), OutTransitions.GetData());
#endif
};




bool FXeSSRHI::EffectRecreationIsRequired(const FXeSSInitArguments& NewArgs) const {
	if (InitArgs.OutputWidth != NewArgs.OutputWidth ||
		InitArgs.OutputHeight != NewArgs.OutputHeight ||
		InitArgs.QualitySetting != NewArgs.QualitySetting)
	{
		return true;
	}
	return false;
}

xess_quality_settings_t GetQualitySettingFromCVarInt(int CVarInt)
{
	uint32_t QualityIndex = static_cast<uint32_t>(XESS_QUALITY_SETTING_BASE_VALUE) + CVarInt;
	xess_quality_settings_t QualitySetting = static_cast<xess_quality_settings_t>(QualityIndex);

	switch (QualitySetting)
	{
	case XESS_QUALITY_SETTING_PERFORMANCE:
	case XESS_QUALITY_SETTING_BALANCED:
	case XESS_QUALITY_SETTING_QUALITY:
	case XESS_QUALITY_SETTING_ULTRA_QUALITY:
		return QualitySetting;
	default:
		return XESS_QUALITY_SETTING_BALANCED;
	}
}

float FXeSSRHI::SetResolutionFraction(const xess_2d_t& OutputResolution, const xess_quality_settings_t QualitySettings)
{
	xess_2d_t InputResolution{};
	xess_result_t Result = xessGetInputResolution(XeSSContext, &OutputResolution, QualitySettings, &InputResolution);
	if (Result != XESS_RESULT_SUCCESS)
	{
		UE_LOG(LogXeSSRHI, Warning, TEXT("Error when calling xessGetInputResolution."));
	}

	float ResolutionFraction = FLOAT(InputResolution.x) / FLOAT(OutputResolution.x);
	return ResolutionFraction;
}

FXeSSRHI::FXeSSRHI(FDynamicRHI* DynamicRHI)
	: D3D12RHI(static_cast<FD3D12DynamicRHI*>(DynamicRHI))
	, Direct3DDevice(D3D12RHI->GetAdapter(0).GetD3DDevice())
{
	check(D3D12RHI);
	check(Direct3DDevice);

	xess_result_t Result = xessD3D12CreateContext(Direct3DDevice, &XeSSContext);
	if (Result == XESS_RESULT_SUCCESS)
	{
		UE_LOG(LogXeSSRHI, Log, TEXT("Intel XeSS effect supported"));
	}
	else
	{
		UE_LOG(LogXeSSRHI, Log, TEXT("Intel XeSS effect NOT supported"));
		return;
	}

	// Print XeFX library version if it was loaded, XeFX will only be used when running on Intel platforms
	xess_version_t XeFXLibVersion;
	if (xessGetIntelXeFXVersion(XeSSContext, &XeFXLibVersion) != XESS_RESULT_SUCCESS)
	{
		UE_LOG(LogXeSSRHI, Warning, TEXT("Error when calling XeSS funciton: xessGetIntelXeFXVersion"));
		return;
	}

	static const auto CVarVersion = IConsoleManager::Get().FindConsoleVariable(TEXT("r.XeSS.Version"));

	// append XeFX library info to version string when running on Intel
	if (XeFXLibVersion.major != XeFXLibVersion.minor != XeFXLibVersion.patch != 0)
	{
		TStringBuilder<32> VersionStringBuilder;
		VersionStringBuilder << CVarVersion->GetString() << " XeFX version: "
			<< XeFXLibVersion.major << "." << XeFXLibVersion.minor << "." << XeFXLibVersion.patch;
		CVarVersion->Set(VersionStringBuilder.GetData());

		UE_LOG(LogXeSSRHI, Log, TEXT("Loading Intel XeFX library %d.%d.%d"),
			XeFXLibVersion.major, XeFXLibVersion.minor, XeFXLibVersion.patch);
	}
	
	//Pre-build XeSS kernel
	xessD3D12BuildPipelines(XeSSContext, nullptr, true, XeSSInitFlags);

	xess_2d_t OutputResolution{ 1000, 1000 };
	MinResolutionFraction = SetResolutionFraction(OutputResolution, XESS_QUALITY_SETTING_PERFORMANCE);
	MaxResolutionFraction = SetResolutionFraction(OutputResolution, XESS_QUALITY_SETTING_ULTRA_QUALITY);

	const auto DefaultQuality = GetQualitySettingFromCVarInt(IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.XeSS.Quality"))->GetValueOnAnyThread());
	CurrentResolutionFraction = SetResolutionFraction(OutputResolution, DefaultQuality);

	bXeSSInitialized = true;
}

FXeSSRHI::~FXeSSRHI()
{
	if (!bXeSSInitialized)
	{
		return;
	}

	xess_result_t Result = xessDestroyContext(XeSSContext);
	if (Result == XESS_RESULT_SUCCESS)
	{
		UE_LOG(LogXeSSRHI, Log, TEXT("Removed Intel XeSS effect"));
	}
	else
	{
		UE_LOG(LogXeSSRHI, Warning, TEXT("Failed to remove XeSS effect"));
		return;
	}
}

void FXeSSRHI::RHIInitializeXeSS(FRHICommandList& CmdList, const FXeSSInitArguments& InArguments)
{
	if (!bXeSSInitialized)
	{
		return;
	}

	UpdateInitArguments(InArguments);

	// set scaling factor
	xess_2d_t OutputResolution{ InArguments.OutputWidth, InArguments.OutputHeight };
	const auto QualitySetting = GetQualitySettingFromCVarInt(InArguments.QualitySetting);
	CurrentResolutionFraction = SetResolutionFraction(OutputResolution, QualitySetting);

	xess_d3d12_init_params_t InitParams = {};
	InitParams.outputResolution.x = InArguments.OutputWidth;
	InitParams.outputResolution.y = InArguments.OutputHeight;
	InitParams.initFlags = XeSSInitFlags;
	InitParams.qualitySetting = QualitySetting;
	InitParams.pPipelineLibrary = nullptr;

	// WA to resolve problem with dxcompiler.dll loading dxil.dll from game's .exe path
	SetDllDirectory(*FPaths::Combine(IPluginManager::Get().FindPlugin("XeSS")->GetBaseDir(), TEXT("/Binaries/ThirdParty/Win64")));

	if (XESS_RESULT_SUCCESS != xessD3D12Init(XeSSContext, &InitParams))
	{
		UE_LOG(LogXeSSRHI, Error, TEXT("Failed to intialize Intel XeSS."));
	}
}

void FXeSSRHI::RHIExecuteXeSS(FRHICommandList& CmdList, const FXeSSExecuteArguments& InArguments)
{
	if (!bXeSSInitialized)
	{
		return;
	}

	xess_d3d12_execute_params_t ExecuteParams{};
	ExecuteParams.pColorTexture = GetD3D12TextureFromRHITexture(InArguments.ColorTexture)->GetResource()->GetResource();
	ExecuteParams.pVelocityTexture = GetD3D12TextureFromRHITexture(InArguments.VelocityTexture)->GetResource()->GetResource();
	ExecuteParams.pOutputTexture = GetD3D12TextureFromRHITexture(InArguments.OutputTexture)->GetResource()->GetResource();

	ExecuteParams.jitterOffsetX = InArguments.JitterOffsetX;
	ExecuteParams.jitterOffsetY = InArguments.JitterOffsetY;
	ExecuteParams.resetHistory = (bool)InArguments.bCameraCut;
	ExecuteParams.inputWidth = InArguments.SrcViewRect.Width();
	ExecuteParams.inputHeight = InArguments.SrcViewRect.Height();
	ExecuteParams.inputColorBase.x = InArguments.SrcViewRect.Min.X;
	ExecuteParams.inputColorBase.y = InArguments.SrcViewRect.Min.Y;
	ExecuteParams.outputColorBase.x = InArguments.DstViewRect.Min.X;
	ExecuteParams.outputColorBase.y = InArguments.DstViewRect.Min.Y;
	ExecuteParams.exposureScale = 1.0f;

	// execute
	FD3D12Device* Device = D3D12RHI->GetAdapter().GetDevice(CmdList.GetGPUMask().ToIndex());
	ID3D12GraphicsCommandList* D3D12CmdList = Device->GetCommandContext().CommandListHandle.GraphicsCommandList();

	ForceBeforeResourceTransition(*D3D12CmdList, ExecuteParams);

	if (XESS_RESULT_SUCCESS != xessD3D12Execute(XeSSContext, D3D12CmdList, &ExecuteParams))
	{
		UE_LOG(LogXeSSRHI, Error, TEXT("Error when executing XeSS."));
	}

	ForceAfterResourceTransition(*D3D12CmdList, ExecuteParams);

	// make sure root signature and heap state is reset
	Device->GetCommandContext().StateCache.ForceSetComputeRootSignature();
	Device->GetCommandContext().StateCache.GetDescriptorCache()->SetCurrentCommandList(Device->GetCommandContext().CommandListHandle);
}

void FXeSSRHI::TriggerFrameCapture(int FrameCount) const
{
	if (FrameCount > 0)
	{
		FString DumpPath = FPaths::ConvertRelativePathToFull(CVarXeSSFrameDumpPath.GetValueOnAnyThread());		
		DumpPath = FPaths::Combine(*DumpPath, FString("XeSS_Dump"));

		if (!IFileManager::Get().MakeDirectory(*DumpPath, /*Tree*/true))
		{
			UE_LOG(LogXeSSRHI, Error, TEXT("XeSS Frame Capture: failed to create directory %s."), *DumpPath);
			return;
		}

		xess_dump_parameters_t DumpParameters = {};
		DumpParameters.path = TCHAR_TO_ANSI(*DumpPath);
		DumpParameters.frame_idx = GFrameNumber;
		DumpParameters.frame_count = FrameCount;
		DumpParameters.dump_elements_mask = XESS_DUMP_ALL;

		if (XESS_RESULT_SUCCESS != xessStartDump(XeSSContext, &DumpParameters))
		{
			UE_LOG(LogXeSSRHI, Error, TEXT("Error when dumping XeSS debug data."));
		}
	}
}

void FXeSSRHI::TriggerResourceTransitions(FRHICommandListImmediate & RHICmdList, FRHIStructuredBuffer * DummyBuffer) const
{
	// using the dummy structured buffer to trigger a resource transition
	RHICmdList.LockStructuredBuffer(DummyBuffer, 0, sizeof(float), EResourceLockMode::RLM_WriteOnly);
	RHICmdList.UnlockStructuredBuffer(DummyBuffer);
}

#undef LOCTEXT_NAMESPACE

