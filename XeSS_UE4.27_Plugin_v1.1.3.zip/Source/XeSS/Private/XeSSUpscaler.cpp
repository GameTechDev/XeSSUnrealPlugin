/*******************************************************************************
 * Copyright 2021 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files(the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions :
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ******************************************************************************/

#include "XeSSUpscaler.h"
#include "XeSSPrePass.h"
#include "XeSSSettings.h"
#include "xess.h"
#include "xess_d3d12.h"
#include "xess_d3d12_debug.h"
#include "xess_debug.h"

#include "PostProcess/SceneRenderTargets.h"
#include "PostProcess/PostProcessing.h"
#include "SceneTextureParameters.h"
#include "ScreenPass.h"

#include "LegacyScreenPercentageDriver.h"

#define LOCTEXT_NAMESPACE "FXeSSPlugin"

// HACK: Variables to save previous global ones
#if ENGINE_MAJOR_VERSION < 5
const ITemporalUpscaler * PreviousGTemporalUpscaler = nullptr;
#endif
ICustomStaticScreenPercentage * PreviousGCustomStaticScreenPercentage = nullptr;

static TAutoConsoleVariable<int32> CVarXeSSEnabled(
	TEXT("r.XeSS.Enabled"),
	0,
	TEXT("[default: 0] Set to 1 to use XeSS instead of TAAU or any other upscaling method."),
	ECVF_Scalability | ECVF_RenderThreadSafe);

static TAutoConsoleVariable<int32> CVarXeSSQuality(
	TEXT("r.XeSS.Quality"),
	2,
	TEXT("[default:2] Set XeSS quality setting.")
	TEXT(" 1: Performance")
	TEXT(" 2: Balanced (default)")
	TEXT(" 3: Quality")
	TEXT(" 4: Ultra Quality"),
	ECVF_Scalability | ECVF_RenderThreadSafe);

static TAutoConsoleVariable<int32> CVarXeSSFrameDump(
	TEXT("r.XeSS.FrameDump"),
	0,
	TEXT("Captures of all input resources passed to XeSS for the specified number of frames."),
	ECVF_Default);

const TCHAR* FXeSSUpscaler::GetDebugName() const
{
	return TEXT("FXeSSPlugin");
}
DECLARE_GPU_STAT_NAMED(XeSS, TEXT("XeSS"));

FIntPoint FXeSSPassParameters::GetOutputExtent() const
{
	check(Validate());
	check(SceneColorInput);

	FIntPoint InputExtent = SceneColorInput->Desc.Extent;

	check(OutputViewRect.Min == FIntPoint::ZeroValue);
	FIntPoint QuantizedPrimaryUpscaleViewSize;
	QuantizeSceneBufferSize(OutputViewRect.Size(), QuantizedPrimaryUpscaleViewSize);

	return FIntPoint(
		FMath::Max(InputExtent.X, QuantizedPrimaryUpscaleViewSize.X),
		FMath::Max(InputExtent.Y, QuantizedPrimaryUpscaleViewSize.Y));
}

bool FXeSSPassParameters::Validate() const
{
	check(OutputViewRect.Min == FIntPoint::ZeroValue);
	return true;
}

bool FXeSSUpscaler::IsXeSSEnabled() const
{
	static const auto TAAUpscalerEnabled = IConsoleManager::Get().FindConsoleVariable(TEXT("r.TemporalAA.Upscaler"))->GetInt();

#if ENGINE_MAJOR_VERSION < 5
	return (TAAUpscalerEnabled != 0) && (CVarXeSSEnabled.GetValueOnAnyThread() != 0) && (GTemporalUpscaler == this);
#else
	return (TAAUpscalerEnabled != 0) && (CVarXeSSEnabled.GetValueOnAnyThread() != 0);
#endif
}

BEGIN_SHADER_PARAMETER_STRUCT(FXeSSShaderParameters, )
	// Init parameters
	SHADER_PARAMETER(FIntRect, OutputRect)

	// Exec parameters
	RDG_TEXTURE_ACCESS(InputColor, ERHIAccess::SRVCompute)
	RDG_TEXTURE_ACCESS(InputVelocity, ERHIAccess::SRVCompute)

	// Only used as WA to force Resource Transition Barrier
	RDG_BUFFER_ACCESS(DummyBuffer, ERHIAccess::UAVCompute)

#if ENGINE_MAJOR_VERSION < 5
	SHADER_PARAMETER(FVector2D, JitterOffset)
#else
	SHADER_PARAMETER(FVector2f, JitterOffset)
#endif
	SHADER_PARAMETER(int32, bCameraCut)
	SHADER_PARAMETER(int32, QualitySetting)

	//Output
	RDG_TEXTURE_ACCESS_DYNAMIC(SceneColorOutput)
END_SHADER_PARAMETER_STRUCT()

FRDGTextureRef FXeSSUpscaler::AddMainXeSSPass(
	FRDGBuilder& GraphBuilder,
	const FViewInfo& View,
	const FXeSSPassParameters& Inputs,
	const FTemporalAAHistory& InputHistory,
	FTemporalAAHistory* OutputHistory) const
{
	check(Inputs.SceneColorInput);
	check(Inputs.SceneDepthTexture);
	check(Inputs.SceneVelocityTexture);

	// HACK: exit if XeSS upscaler is not active, allows to have multiple upscalers loaded by project
	if (!IsXeSSEnabled())
	{
		return nullptr;
	}

	check(IsXeSSEnabled());

	RDG_GPU_STAT_SCOPE(GraphBuilder, XeSS);

	// Whether to use camera cut shader permutation or not.
	const bool bCameraCut = !InputHistory.IsValid() || View.bCameraCut;

	const FIntPoint OutputExtent = Inputs.GetOutputExtent();
	const FIntRect SrcRect = Inputs.InputViewRect;
	const FIntRect DestRect = Inputs.OutputViewRect;

	// Create outputs
	FRDGTextureDesc OutputColorDesc = Inputs.SceneColorInput->Desc;
	OutputColorDesc.Extent = OutputExtent;
	OutputColorDesc.Flags = TexCreate_ShaderResource | TexCreate_UAV;

	FRDGTexture* OutputSceneColor = GraphBuilder.CreateTexture(
		OutputColorDesc,
		TEXT("XeSSOutputSceneColor"),
		ERDGTextureFlags::MultiFrame);

	FXeSSShaderParameters* PassParameters = GraphBuilder.AllocParameters<FXeSSShaderParameters>();
	PassParameters->OutputRect = DestRect;

	PassParameters->InputColor = Inputs.SceneColorInput;
	PassParameters->InputVelocity = Inputs.SceneVelocityTexture;

	float InputViewSizeInvScale = (Inputs.ResolutionDivisor == 0 ? 1.0 : Inputs.ResolutionDivisor);
	float InputViewSizeScale = 1.0f / InputViewSizeInvScale;

#if ENGINE_MAJOR_VERSION < 5
	PassParameters->JitterOffset = InputViewSizeScale * View.TemporalJitterPixels;
#else
	PassParameters->JitterOffset = InputViewSizeScale * FVector2f(View.TemporalJitterPixels);
#endif
	PassParameters->bCameraCut = bCameraCut;
	PassParameters->SceneColorOutput = FRDGTextureAccess(OutputSceneColor, ERHIAccess::UAVCompute);
	PassParameters->QualitySetting = CVarXeSSQuality.GetValueOnAnyThread();
	PassParameters->DummyBuffer = GraphBuilder.CreateBuffer(FRDGBufferDesc::CreateStructuredDesc((uint32)sizeof(float), 1u), TEXT("ForceTransitionDummyBuffer"));

	FXeSSRHI* LocalXeSSRHI = this->UpscalerXeSSRHI;

	GraphBuilder.AddPass(
		RDG_EVENT_NAME("XeSS Main Pass"),
		PassParameters,
		ERDGPassFlags::Compute,
		[LocalXeSSRHI, PassParameters, Inputs](FRHICommandListImmediate& RHICmdList)
		{
			FXeSSInitArguments InitArgsXeSS;

			InitArgsXeSS.OutputWidth = PassParameters->OutputRect.Width();
			InitArgsXeSS.OutputHeight = PassParameters->OutputRect.Height();
			InitArgsXeSS.QualitySetting = PassParameters->QualitySetting;

			FXeSSExecuteArguments ExecArgsXeSS;
			check(PassParameters->InputColor);
			PassParameters->InputColor->MarkResourceAsUsed();
			ExecArgsXeSS.ColorTexture = PassParameters->InputColor->GetRHI();

			check(PassParameters->InputVelocity);
			PassParameters->InputVelocity->MarkResourceAsUsed();
			ExecArgsXeSS.VelocityTexture = PassParameters->InputVelocity->GetRHI();

			check(PassParameters->SceneColorOutput);
			PassParameters->SceneColorOutput->MarkResourceAsUsed();
			ExecArgsXeSS.OutputTexture = PassParameters->SceneColorOutput->GetRHI();

			ExecArgsXeSS.JitterOffsetX = PassParameters->JitterOffset.X;
			ExecArgsXeSS.JitterOffsetY = PassParameters->JitterOffset.Y;

			ExecArgsXeSS.bCameraCut = PassParameters->bCameraCut;

			ExecArgsXeSS.SrcViewRect = Inputs.InputViewRect;
			ExecArgsXeSS.DstViewRect = Inputs.OutputViewRect;

			check(PassParameters->DummyBuffer);
			PassParameters->DummyBuffer->MarkResourceAsUsed();

			if (LocalXeSSRHI->EffectRecreationIsRequired(InitArgsXeSS))
			{
				// invalidate history if XeSS is reinitialized
				ExecArgsXeSS.bCameraCut = 1;
				// Make sure all cmd lists in flight have complete before XeSS re-init
				RHICmdList.BlockUntilGPUIdle();
				RHICmdList.EnqueueLambda(
					[LocalXeSSRHI, InitArgsXeSS](FRHICommandListImmediate& Cmd)
					{
						LocalXeSSRHI->RHIInitializeXeSS(Cmd, InitArgsXeSS);
					});
			}

			// make sure all resource transitions barriers are executed before RHIExecuteXeSS is called
			LocalXeSSRHI->TriggerResourceTransitions(RHICmdList, PassParameters->DummyBuffer->GetRHIStructuredBuffer());

			RHICmdList.EnqueueLambda(
				[LocalXeSSRHI, ExecArgsXeSS](FRHICommandListImmediate& Cmd)
				{
					LocalXeSSRHI->RHIExecuteXeSS(Cmd, ExecArgsXeSS);
				});
		});

	if (!View.bStatePrevViewInfoIsReadOnly)
	{
		OutputHistory->SafeRelease();

		GraphBuilder.QueueTextureExtraction(OutputSceneColor, &OutputHistory->RT[0]);
		OutputHistory->ViewportRect = DestRect;
		OutputHistory->ReferenceBufferSize = OutputExtent;
	}

	return OutputSceneColor;
};

#if ENGINE_MAJOR_VERSION < 5
void FXeSSUpscaler::AddPasses(
	FRDGBuilder& GraphBuilder,
	const FViewInfo& View,
	const FPassInputs& PassInputs,
	FRDGTextureRef* OutSceneColorTexture,
	FIntRect* OutSceneColorViewRect,
	FRDGTextureRef* OutSceneColorHalfResTexture,
	FIntRect* OutSceneColorHalfResViewRect) const
#else
	ITemporalUpscaler::FOutputs FXeSSUpscaler::AddPasses(
		FRDGBuilder& GraphBuilder,
		const FViewInfo& View,
	const FPassInputs& PassInputs) const
#endif
{
	// HACK: exit if XeSS upscaler is not active, allows to have multiple upscalers loaded by project
#if ENGINE_MAJOR_VERSION < 5
	if (!IsXeSSEnabled())
	{
		return;
	}
#else
	ITemporalUpscaler::FOutputs Outputs{};
	if (!IsXeSSEnabled())
	{
		return Outputs;
	}
#endif

	RDG_EVENT_SCOPE(GraphBuilder, "XeSS Pass");

	const FRDGTextureRef XeSSUpscaledVelocity = AddVelocityFlatteningXeSSPass(GraphBuilder,
		PassInputs.SceneDepthTexture,
		PassInputs.SceneVelocityTexture,
		View);

	FXeSSPassParameters XeSSMainParameters(View);
	XeSSMainParameters.SetupViewRect(View);
	XeSSMainParameters.SceneColorInput = PassInputs.SceneColorTexture;
	XeSSMainParameters.InputViewRect = View.ViewRect;
	XeSSMainParameters.SceneVelocityTexture = XeSSUpscaledVelocity;
	XeSSMainParameters.SceneDepthTexture = PassInputs.SceneDepthTexture;

	const FIntRect SecondaryViewRect = XeSSMainParameters.OutputViewRect;

	const FTemporalAAHistory& InputHistory = View.PrevViewInfo.TemporalAAHistory;
	FTemporalAAHistory& OutputHistory = View.ViewState->PrevFrameViewInfo.TemporalAAHistory;

	const FRDGTextureRef XeSSOutput = AddMainXeSSPass(
		GraphBuilder,
		View,
		XeSSMainParameters,
		InputHistory,
		&OutputHistory);


	// HACK: Fix crash issue when actived with other upscaler plugins at the same time
#if ENGINE_MAJOR_VERSION < 5
	if (!XeSSOutput)
	{
		return;
	}

	*OutSceneColorTexture = XeSSOutput;
	*OutSceneColorViewRect = SecondaryViewRect;
#else
	if (!XeSSOutput)
	{
		return Outputs;
	}
	Outputs.FullRes.Texture = XeSSOutput;
	Outputs.FullRes.ViewRect = SecondaryViewRect;

	return Outputs;		
#endif
}

// Inherited via ICustomStaticScreenPercentage
void FXeSSUpscaler::SetupMainGameViewFamily(FSceneViewFamily& ViewFamily)
{
	if (!IsXeSSEnabled())
	{
		return;
	}
#if (ENGINE_MAJOR_VERSION < 5) 
	checkf(GTemporalUpscaler == this, TEXT("GTemporalUpscaler is not set to a XeSS, please make sure no other upscaling plug is enabled."));
#endif
	checkf(GCustomStaticScreenPercentage == this, TEXT("GCustomStaticScreenPercentage is not set to a XeSS, please make sure no other upscaling plug is enabled."));

	if (!GIsEditor || GetDefault<UXeSSSettings>()->bEnableXeSSInEditorViewports)
	{
		ViewFamily.SetTemporalUpscalerInterface(this);

		if (ViewFamily.EngineShowFlags.ScreenPercentage && !ViewFamily.GetScreenPercentageInterface())
		{
			const float ResolutionFraction = UpscalerXeSSRHI->GetCurrentResolutionFraction();
			ViewFamily.SetScreenPercentageInterface(new FLegacyScreenPercentageDriver(
				ViewFamily, ResolutionFraction
#if (ENGINE_MAJOR_VERSION < 5) 
				, /*InAllowPostProcessSettingsScreenPercentage*/ false
#endif
			));
		}
	}
}

#if (ENGINE_MAJOR_VERSION >= 5) || ((ENGINE_MAJOR_VERSION == 4) && (ENGINE_MINOR_VERSION >= 27))
void FXeSSUpscaler::SetupViewFamily(FSceneViewFamily& ViewFamily, TSharedPtr<ICustomStaticScreenPercentageData> InScreenPercentageDataInterface)
{
	check(InScreenPercentageDataInterface.IsValid());
	if (!IsXeSSEnabled())
	{
		return;
	}
#if (ENGINE_MAJOR_VERSION < 5) 
	checkf(GTemporalUpscaler == this, TEXT("GTemporalUpscaler is not set to a XeSS, please make sure no other upscaling plug is enabled."));
#endif
	checkf(GCustomStaticScreenPercentage == this, TEXT("GCustomStaticScreenPercentage is not set to a XeSS, please make sure no other upscaling plug is enabled."));

	ViewFamily.SetTemporalUpscalerInterface(this);

	if (ViewFamily.EngineShowFlags.ScreenPercentage && !ViewFamily.GetScreenPercentageInterface())
	{
		const float ResolutionFraction = UpscalerXeSSRHI->GetCurrentResolutionFraction();
		ViewFamily.SetScreenPercentageInterface(new FLegacyScreenPercentageDriver(
			ViewFamily, ResolutionFraction
#if (ENGINE_MAJOR_VERSION < 5) 
			, /*InAllowPostProcessSettingsScreenPercentage*/ false
#endif
		));
	}
}
#endif

float FXeSSUpscaler::GetMinUpsampleResolutionFraction() const
{
	return UpscalerXeSSRHI->GetMinSupportedResolutionFraction();
}

float FXeSSUpscaler::GetMaxUpsampleResolutionFraction() const
{
	return UpscalerXeSSRHI->GetMaxSupportedResolutionFraction();
}

FXeSSRHI* FXeSSUpscaler::UpscalerXeSSRHI;

FXeSSUpscaler::FXeSSUpscaler(FXeSSRHI* XeSSRHI)
{
	UE_LOG(LogXeSS, Log, TEXT("Created XeSS Upscaler"));

	UpscalerXeSSRHI = XeSSRHI;

	// HACK: assignment of GTemporalUpscaler and GCustomStaticScreenPercentage moved from StartupModule()
	CVarXeSSEnabled->AsVariable()->SetOnChangedCallback(FConsoleVariableDelegate::CreateLambda([this](IConsoleVariable* InVariable)
		{
			// return if no change as bool
			if (bCurrentXeSSEnabled == InVariable->GetBool())
			{
				return;
			}
			bCurrentXeSSEnabled = InVariable->GetBool();
			if (!bCurrentXeSSEnabled)
			{
#if ENGINE_MAJOR_VERSION < 5
				GTemporalUpscaler = PreviousGTemporalUpscaler;
#endif
				GCustomStaticScreenPercentage = PreviousGCustomStaticScreenPercentage;
			}
			else
			{
#if ENGINE_MAJOR_VERSION < 5
				PreviousGTemporalUpscaler = GTemporalUpscaler;
				GTemporalUpscaler = this;
#endif
				PreviousGCustomStaticScreenPercentage = GCustomStaticScreenPercentage;
				GCustomStaticScreenPercentage = this;

				// re-initialize XeSS each time it is re-enbled
				FXeSSInitArguments InitArgsXeSS{};
				UpscalerXeSSRHI->UpdateInitArguments(InitArgsXeSS);
			}
		}));

	// Register callback to handle frame capture requests
	CVarXeSSFrameDump->AsVariable()->SetOnChangedCallback(FConsoleVariableDelegate::CreateLambda([this](IConsoleVariable* InVariable)
		{
			if (!CVarXeSSEnabled.GetValueOnAnyThread())
			{
				UE_LOG(LogXeSS, Warning, TEXT("XeSS is not enabled - please make sure r.XeSS.Enbled is set to 1 before starting frame capture."));
				return;
			}
			UpscalerXeSSRHI->TriggerFrameCapture(InVariable->GetInt());
		}));

	// Make sure to apply any XeSS settings selected prior to module creation
	auto XeSSEnabled = CVarXeSSEnabled->GetInt();
	auto XeSSQuality = CVarXeSSQuality->GetInt();

	CVarXeSSQuality->Set(XeSSQuality, ECVF_SetByConsole);
	CVarXeSSEnabled->Set(XeSSEnabled, ECVF_SetByConsole);
}

FXeSSUpscaler::~FXeSSUpscaler()
{
	UE_LOG(LogXeSS, Log, TEXT("Removed XeSS Upscaler"));
}

#undef LOCTEXT_NAMESPACE