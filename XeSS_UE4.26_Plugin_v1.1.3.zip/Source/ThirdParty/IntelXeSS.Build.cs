/*******************************************************************************
 * Copyright 2021 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files(the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions :
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 ******************************************************************************/

using System;
using System.IO;
using UnrealBuildTool;

public class IntelXeSS : ModuleRules
{
	public IntelXeSS(ReadOnlyTargetRules Target) : base(Target)
	{
		Type = ModuleType.External;

		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			string[] XeSSDLLs =
			{
				"dxcompiler.dll",
				"dxil.dll",
				"XeFX.dll",
				"igxess.dll",
				"libxess.dll",
				"XeFX_Loader.dll",
			};

			string[] XeSSLibs =
			{
				"libxess.lib",
			};

			string XeSSLibsPath			= "$(PluginDir)/Source/ThirdParty/lib";
			string XeSSApiPath			= "$(PluginDir)/Source/ThirdParty/api";
			string XeSSBinariesPath		= "$(PluginDir)/Binaries/ThirdParty/Win64/";

			PublicSystemIncludePaths.Add(XeSSApiPath);
			PublicIncludePaths.Add(XeSSApiPath);

			foreach (string LibFile in XeSSLibs)
			{
				PublicAdditionalLibraries.Add(Path.Combine(XeSSLibsPath, LibFile));
			}
			foreach (string DllFile in XeSSDLLs)
			{
				PublicDelayLoadDLLs.Add(DllFile);
				RuntimeDependencies.Add(Path.Combine(XeSSBinariesPath, DllFile), StagedFileType.NonUFS);
			}
		}
	}
}